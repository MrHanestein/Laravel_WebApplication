<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/public"
    <?php echo $__env->make('home.homecss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="header_section">
<?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div style="text-align: center;" class="col-md-13">
    <div><img style="padding: 20px; margin-bottom: 20px; height: 200px" width="350px" src="/postimage/<?php echo e($post->image); ?>"></div>
    <h4><?php echo e($post->title); ?></h4>
    <p>Posted By <b><?php echo e($post->name); ?></b></p>

    <div class="btn_main"><a href="<?php echo e(url('post_details',$post->id)); ?>">Read More</a></div>
<?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</div>
</html>
<?php /**PATH /Users/davidanthony/Documents/GitHub/Laravel_WebApplication/laravel_Coursework/resources/views/home/post_details.blade.php ENDPATH**/ ?>