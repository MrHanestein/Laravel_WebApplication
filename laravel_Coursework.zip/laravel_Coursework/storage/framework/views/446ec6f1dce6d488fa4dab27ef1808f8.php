<!DOCTYPE html>
<html>
<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .title_deg
        {
            font-size: 20px;
            font-weight: bold;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .table_deg
        {
            border: 2px solid pink;
            width: 70%;
            text-align: center;
            margin-left: 70px;
        }
        .th_deg
        {
            background-color: purple;
        }
        .img_deg
        {
            height: 90px;
            width: 160px;
            padding: 10px;
        }
    </style>
</head>
<body>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="d-flex align-items-stretch">
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-content">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <h1 class="title_deg">All Post</h1>
        <table class="table_deg">
            <tr class="th_deg ">
                <th>Post Title</th>
                <th>Description</th>
                <th>Post By</th>
                <th>Post Status</th>
                <th>UserType</th>
                <th>Image</th>
                <th>Delete</th>
                <th>Edit</th>
            </tr>=-890-90-
            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->description); ?></td>
                <td><?php echo e($post->name); ?></td>
                <td><?php echo e($post->post_status); ?></td>
                <td><?php echo e($post->usertype); ?></td>
                <td>
                    <img class="img_deg" src="postimage/<?php echo e($post->image); ?>">
                </td>
                <td>
                    <a href="<?php echo e(url('delete_post',$post->id)); ?>" class="btn btn-danger" onclick="confirmation(event)">Delete</a>
                </td>
                <td>
                    <a href="<?php echo e(url('edit_page',$post->id)); ?>" class="btn btn-success">Edit</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function confirmation(ev) {
            ev.preventDefault();
            var urlToRedirect = ev.currentTarget.getAttribute('href');
            console.log(urlToRedirect);
            swal({
                title: "Are you sure to Delete this post",
                text: "You will not be able to revert this!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willCancel) => {
                    if (willCancel) {



                        window.location.href = urlToRedirect;

                    }


                });


        }
    </script>
</div>"
</body>
</html>

<?php /**PATH /Users/davidanthony/Documents/GitHub/Laravel_WebApplication/laravel_Coursework/resources/views/admin/show_post.blade.php ENDPATH**/ ?>