<!-- services section start -->
<div class="services_section layout_padding">
    <div class="container">
        <h1 class="services_taital">Blog Posts Here </h1>
        <p class="services_text">There are many variations of passages of Lorem Ipsum available in this blog, but the majority have suffered different alterations.</p>
        <div class="services_section_2">
            <div class="row">
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div><img style="margin-bottom: 20px; height: 200px" width="350px" src="/postimage/<?php echo e($post->image); ?>"></div>
                    <h4><?php echo e($post->title); ?></h4>
                    <p>Posted By <b><?php echo e($post->name); ?></b></p>

                    <div class="btn_main"><a href="<?php echo e(url('post_details',$post->id)); ?>">Read More</a></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<!-- services section end -->
<?php /**PATH /Users/davidanthony/Documents/GitHub/Laravel_WebApplication/laravel_Coursework/resources/views/home/services.blade.php ENDPATH**/ ?>