<!DOCTYPE html>
<html lang="en">
<head>
    @include('home.homecss')
</head>
<body>

@include('home.header')

@include('home.banner')

@include('home.services')

@include('home.about')

@include('home.footer')
</body>
</html>
