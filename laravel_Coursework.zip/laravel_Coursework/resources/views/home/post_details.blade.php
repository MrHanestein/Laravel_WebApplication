<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/public"
    @include('home.homecss')
</head>
<body>
<div class="header_section">
@include('home.header')
</div>
<div style="text-align: center;" class="col-md-13">
    <div><img style="padding: 20px; margin-bottom: 20px; height: 200px" width="350px" src="/postimage/{{$post->image}}"></div>
    <h4>{{$post->title}}</h4>
    <p>Posted By <b>{{$post->name}}</b></p>

    <div class="btn_main"><a href="{{url('post_details',$post->id)}}">Read More</a></div>
@include('home.footer')
</body>
</div>
</html>
